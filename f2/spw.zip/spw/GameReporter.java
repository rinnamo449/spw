package f2.spw;

public interface GameReporter {

	long getScore();
	int getDead();

}
