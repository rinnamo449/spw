package f2.spw;

public interface GameReporter {

	long getScore();
	int getStop();
	int getDead();
    int getLifeboss();
}
